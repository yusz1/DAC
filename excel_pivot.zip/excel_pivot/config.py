# 文件路径配置
EXCEL_PATH = r"D:\Projects\Test\data\test_data_rate.xlsx"

# 基础配置
BASE_NUMBER = 1000  # 统计基数

# 需要提取的原始列
EXTRACT_COLUMNS = ['SN', '不良录入时间', '线体', '不良代码']

# 时间统计配置
TIME_COLUMN = '不良录入时间'  # 用于时间统计的列
GROUP_COLUMNS = ['线体', '不良代码']  # 除时间外的分组列