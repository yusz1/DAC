import pandas as pd
import os
from config import EXCEL_PATH, BASE_NUMBER, EXTRACT_COLUMNS

def create_line_stats(df):
    """创建按线体统计"""
    defect_codes = sorted(df['不良代码'].unique())
    
    # 创建结果数据
    result_data = []
    
    # 按线体统计
    for line in sorted(df['线体'].unique()):
        line_df = df[df['线体'] == line]
        
        # 统计该线体下的各类不良数量
        row_data = {
            '线体': line,
            '基数': BASE_NUMBER
        }
        
        # 统计每种不良代码的SN数量
        for code in defect_codes:
            sn_count = len(line_df[line_df['不良代码'] == code]['SN'].unique())
            row_data[code] = sn_count
            row_data[f"{code}(%)"] = round(sn_count / BASE_NUMBER * 100, 1)
        
        result_data.append(row_data)
    
    # 添加总计行
    total_data = {'线体': '总计', '基数': BASE_NUMBER}
    for code in defect_codes:
        total_sn_count = len(df[df['不良代码'] == code]['SN'].unique())
        total_data[code] = total_sn_count
        total_data[f"{code}(%)"] = round(total_sn_count / BASE_NUMBER * 100, 1)
    
    result_data.append(total_data)
    
    # 创建DataFrame
    result_columns = ['线体', '基数']
    for code in defect_codes:
        result_columns.extend([code, f"{code}(%)"])
    
    return pd.DataFrame(result_data, columns=result_columns)

def create_time_stats(df, time_period='D'):
    """创建时间统计表"""
    # 确保时间列为datetime类型
    df['不良录入时间'] = pd.to_datetime(df['不良录入时间'])
    
    # 创建时间分组
    if time_period == 'D':
        df['时间分组'] = df['不良录入时间'].dt.date
    else:  # 'W'
        df['时间分组'] = df['不良录入时间'].dt.strftime('%Y-W%U')
    
    # 获取所有不良代码
    defect_codes = sorted(df['不良代码'].unique())
    
    # 创建结果数据
    result_data = []
    
    # 按时间分组统计
    for time_group in sorted(df['时间分组'].unique()):
        time_df = df[df['时间分组'] == time_group]
        
        # 统计该时间下的各类不良数量
        row_data = {
            '时间': time_group,
            '基数': BASE_NUMBER
        }
        
        # 统计每种不良代码的SN数量
        for code in defect_codes:
            sn_count = len(time_df[time_df['不良代码'] == code]['SN'].unique())
            row_data[code] = sn_count
            row_data[f"{code}(%)"] = round(sn_count / BASE_NUMBER * 100, 1)
        
        result_data.append(row_data)
    
    # 添加总计行
    total_data = {'时间': '总计', '基数': BASE_NUMBER}
    for code in defect_codes:
        total_sn_count = len(df[df['不良代码'] == code]['SN'].unique())
        total_data[code] = total_sn_count
        total_data[f"{code}(%)"] = round(total_sn_count / BASE_NUMBER * 100, 1)
    
    result_data.append(total_data)
    
    # 创建DataFrame
    result_columns = ['时间', '基数']
    for code in defect_codes:
        result_columns.extend([code, f"{code}(%)"])
    
    return pd.DataFrame(result_data, columns=result_columns)

def create_formatted_pivot():
    try:
        # 读取Excel文件
        df = pd.read_excel(EXCEL_PATH)
        
        # 1. 创建不分组的总体统计表
        defect_codes = sorted(df['不良代码'].unique())

        # 创建总体统计数据
        overall_data = []
        for code in defect_codes:
            sn_count = len(df[df['不良代码'] == code]['SN'].unique())
            overall_data.append({
                '不良代码': code,
                '基数': BASE_NUMBER,
                '数量': sn_count,
                '不良率(%)': round(sn_count / BASE_NUMBER * 100, 1)
            })
        # 创建DataFrame并按不良率降序排序
        overall_stats = pd.DataFrame(overall_data)
        overall_stats = overall_stats.sort_values('不良率(%)', ascending=False)

        # 添加总计行
        total_count = overall_stats['数量'].sum()
        total_row = pd.DataFrame([{
            '不良代码': '总计',
            '基数': BASE_NUMBER,
            '数量': total_count,
            '不良率(%)': round(total_count / BASE_NUMBER * 100, 1)
        }])
        # 合并排序后的数据和总计行
        overall_stats = pd.concat([overall_stats, total_row], ignore_index=True)
        # 2. 创建三个分组统计表
        line_stats = create_line_stats(df)
        daily_stats = create_time_stats(df, 'D')
        weekly_stats = create_time_stats(df, 'W')
        
        # 构建输出文件路径
        file_dir = os.path.dirname(EXCEL_PATH)
        file_name = os.path.basename(EXCEL_PATH)
        base_name, _ = os.path.splitext(file_name)
        output_path = os.path.join(file_dir, f"{base_name}_result.xlsx")
        
        # 检查文件是否被占用，如果存在则先尝试删除
        if os.path.exists(output_path):
            try:
                os.remove(output_path)
                print(f"已删除旧文件: {output_path}")
            except Exception as e:
                print(f"无法删除旧文件，请确保文件未被其他程序打开: {str(e)}")
                return
        
        try:
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                # 保存所有sheet
                df[EXTRACT_COLUMNS].to_excel(writer, sheet_name='原始数据', index=False)
                overall_stats.to_excel(writer, sheet_name='总体统计', index=False)
                line_stats.to_excel(writer, sheet_name='按线体统计', index=False)
                daily_stats.to_excel(writer, sheet_name='按天统计', index=False)
                weekly_stats.to_excel(writer, sheet_name='按周统计', index=False)
                
                # 设置所有sheet的列宽
                workbook = writer.book
                for sheet_name, df_to_adjust in {
                    '原始数据': df[EXTRACT_COLUMNS],
                    '总体统计': overall_stats,
                    '按线体统计': line_stats,
                    '按天统计': daily_stats,
                    '按周统计': weekly_stats
                }.items():
                    worksheet = writer.sheets[sheet_name]
                    for i, col in enumerate(df_to_adjust.columns):
                        max_length = max(
                            df_to_adjust[col].astype(str).apply(len).max(),
                            len(str(col))
                        )
                        worksheet.column_dimensions[chr(65 + i)].width = max_length + 2
            
            print(f"文件已成功保存至: {output_path}")
            
        except Exception as e:
            print(f"保存文件时出错: {str(e)}")
            if os.path.exists(output_path):
                try:
                    os.remove(output_path)
                    print("已删除未完成的文件")
                except:
                    pass
        
    except Exception as e:
        print(f"处理失败: {str(e)}")
        print("请确保：")
        print("1. Excel文件未被其他程序打开")
        print("2. 您有权限访问和修改该文件")
        print("3. 文件路径正确")

if __name__ == "__main__":
    create_formatted_pivot()